<?php
return [
    'host' => "localhost",
    'user' => "root",
    'pw' => "",
    'db' => "m307_yannick"
];